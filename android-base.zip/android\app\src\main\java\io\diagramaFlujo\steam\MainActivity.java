package io.diagramaFlujo.steam;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
